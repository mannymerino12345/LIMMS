<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\limms3.0\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>