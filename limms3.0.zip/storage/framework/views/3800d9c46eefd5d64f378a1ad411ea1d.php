

<?php $__env->startSection('admin'); ?>
<div class="content-body">
    <!-- Page Headings Start -->
    <div class="row justify-content-between align-items-center mb-10">
        <div class="col-12 col-lg-auto mb-20">
            <div class="page-heading">
                <h3 class="title">Edit Item</h3>
            </div>
        </div>
    </div>
    <!-- Page Headings End -->

    <div class="row">
        <div class="col-12 mb-30">
            <div class="box">
                <div class="box-head">
                    <h3 class="title">Edit Item Details</h3>
                </div>
                <div class="box-body">
                    <!-- Feedback Messages -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <!-- Edit Form -->
                    <form action="<?php echo e(route('admin.items.update', $item->item_id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <!-- Item Name -->
                        <div class="mb-3">
                            <label for="item_name" class="form-label">Item Name</label>
                            <input type="text" class="form-control" id="item_name" name="item_name" value="<?php echo e($item->item_name); ?>" required>
                        </div>

                        <!-- Item Description -->
                        <div class="mb-3">
                            <label for="item_description" class="form-label">Item Description</label>
                            <textarea class="form-control" id="item_description" name="item_description" rows="3" required><?php echo e($item->item_description); ?></textarea>
                        </div>

                        <!-- Quantity -->
                        <div class="mb-3">
                            <label for="quantity" class="form-label">Quantity</label>
                            <input type="number" class="form-control" id="quantity" name="quantity" value="<?php echo e($item->quantity); ?>" required>
                        </div>

                        <!-- Category -->
                        <div class="mb-3">
                            <label for="category_id" class="form-label">Category</label>
                            <select class="form-select" id="category_id" name="category_id" required>
                                <option value="">Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->category_id); ?>" <?php echo e($item->category_id == $category->category_id ? 'selected' : ''); ?>>
                                        <?php echo e($category->category_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Laboratory -->
                        <div class="mb-3">
                            <label for="laboratory_id" class="form-label">Laboratory</label>
                            <select class="form-select" id="laboratory_id" name="laboratory_id" required>
                                <option value="">Select Laboratory</option>
                                <?php $__currentLoopData = $laboratories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laboratory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($laboratory->lab_id); ?>" <?php echo e($item->laboratory_id == $laboratory->lab_id ? 'selected' : ''); ?>>
                                        <?php echo e($laboratory->lab_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Item Image -->
                        <div class="mb-3">
                            <label for="item_image" class="form-label">Item Image</label>
                            <input type="file" class="form-control" id="item_image" name="item_image">
                            <?php if($item->item_image): ?>
                                <img src="<?php echo e(asset('' . $item->item_image)); ?>" alt="Current Image" width="100" height="100" class="mt-2">
                                <?php else: ?>
                                <div class="mb-2">
                                    <p>No Image Available</p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Days -->
                        <div class="mb-3">
                            <label for="days" class="form-label">Days</label>
                            <input type="number" class="form-control" id="days" name="days" value="<?php echo e($item->days); ?>" required>
                        </div>

                        <button type="submit" class="btn btn-primary">Update Item</button>
                        <a href="<?php echo e(route('admin.items.table')); ?>" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\limms3.0\resources\views/admin/admin_items_management/admin_items_edit.blade.php ENDPATH**/ ?>