

<?php $__env->startSection('staff'); ?>
<div class="content-body">

    <!-- Page Headings Start -->
    <div class="row justify-content-between align-items-center mb-10">

        <!-- Page Heading Start -->
        <div class="col-12 col-lg-auto mb-20">
            <div class="page-heading">
                <h3>Dashboard <span>/ Staff</span></h3>
            </div>
        </div><!-- Page Heading End -->

        <!-- Page Button Group Start -->
        <div class="col-12 col-lg-auto mb-20">
            <div class="page-date-range">
                <input type="text" class="form-control input-date-predefined">
            </div>
        </div><!-- Page Button Group End -->

    </div><!-- Page Headings End -->

    <!-- Top Report Wrap Start -->
    <div class="row">

        <!-- Total Users Report -->
        <div class="col-xlg-3 col-md-6 col-12 mb-30">
            <div class="top-report">
                <div class="head">
                    <h4>Total Users</h4>
                </div>
                <div class="content">
                    <h5>Total Users: <?php echo e($userCount); ?></h5>
                </div>
            </div>
        </div><!-- Total Users End -->

        <!-- Total Items Report -->
        <div class="col-xlg-3 col-md-6 col-12 mb-30">
            <div class="top-report">
                <div class="head">
                    <h4>Total Items</h4>
                </div>
                <div class="content">
                    <h5>Total Items: <?php echo e($itemCount); ?></h5>
                </div>
            </div>
        </div><!-- Total Items End -->

        <!-- Approved Transactions Report -->
        <div class="col-xlg-3 col-md-6 col-12 mb-30">
            <div class="top-report">
                <div class="head">
                    <h4>Approved Transactions</h4>
                </div>
                <div class="content">
                    <h5>Approved: <?php echo e($approvedCount); ?> / <?php echo e($transactionCount); ?></h5>
                    <!-- Progress Bar -->
                    
                </div>
            </div>
        </div><!-- Approved Transactions End -->

        <!-- Returned Transactions Report -->
        <div class="col-xlg-3 col-md-6 col-12 mb-30">
            <div class="top-report">
                <div class="head">
                    <h4>Returned Transactions</h4>
                </div>
                <div class="content">
                    <h5>Returned: <?php echo e($returnedCount); ?> / <?php echo e($transactionCount); ?></h5>
                    <!-- Progress Bar -->
                    
                </div>
            </div>
        </div><!-- Returned Transactions End -->

    </div><!-- Top Report Wrap End -->
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('staff.staff_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\limms3.0\resources\views/staff/index.blade.php ENDPATH**/ ?>