

<?php $__env->startSection('admin'); ?>
<div class="content-body">
    <!-- Page Headings Start -->
    <div class="row justify-content-between align-items-center mb-10">
        <div class="col-12 col-lg-auto mb-20">
            <div class="page-heading">
                <h3 class="title">Edit Laboratory</h3>
            </div>
        </div>
    </div>
    <!-- Page Headings End -->

    <div class="row">
        <div class="col-12 mb-30">
            <div class="box">
                <div class="box-head">
                    <h3 class="title">Edit Laboratory Details</h3>
                </div>
                <div class="box-body">
                    <!-- Feedback Messages -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <!-- Edit Form -->
                    <form action="<?php echo e(route('admin.laboratory.update', $lab->lab_id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                    
                        <div class="mb-3">
                            <label for="lab_name" class="form-label">Lab Name</label>
                            <input type="text" class="form-control" id="lab_name" name="lab_name" value="<?php echo e($lab->lab_name); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="lab_image" class="form-label">Lab Image</label>
                            <?php if($lab->lab_image && file_exists(public_path($lab->lab_image))): ?>
                                <div class="mb-2">
                                    <img src="<?php echo e(asset($lab->lab_image)); ?>" alt="Lab Image" style="width: 100px; height: 100px;">
                                </div>
                            <?php else: ?>
                                <div class="mb-2">
                                    <p>No Image Available</p>
                                </div>
                            <?php endif; ?>

                            <input type="file" class="form-control" id="lab_image" name="lab_image">
                        </div>
                    
                        <button type="submit" class="btn btn-primary">Update Laboratory</button>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\limms3.0\resources\views/admin/admin_laboratory_management/admin_laboratory_edit.blade.php ENDPATH**/ ?>