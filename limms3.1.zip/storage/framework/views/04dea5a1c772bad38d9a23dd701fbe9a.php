

<?php $__env->startSection('admin'); ?>
<!-- Content Body Start -->
<div class="content-body">

    <!-- Page Headings Start -->
    <div class="row justify-content-between align-items-center mb-10">
        <!-- Page Heading Start -->
        <div class="col-12 col-lg-auto mb-20">
            <div class="page-heading">
                <h3 class="title">Staff <span>/ Settings</span></h3>
            </div>
        </div>
        <!-- Page Heading End -->
    </div>
    <!-- Page Headings End -->

    <!-- Staff Settings List Start -->
    <div class="row mbn-30">

        <?php $__currentLoopData = $staffSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staffSetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 col-12 mb-30">
                <div class="box shadow-lg rounded-lg p-4">
                    
                    <!-- Staff Name Section -->
                    <div class="box-head mb-3 d-flex justify-content-between align-items-center">
                        <!-- Staff Name -->
                        <h4 class="title text-primary mb-0">Name: <?php echo e($staffSetting->user->name); ?></h4>
                        <h4 class="title text-primary mb-0">ID Number: <?php echo e($staffSetting->user->id_number); ?></h4>

                        
                        <!-- Staff Photo -->
                        <div class="flex-shrink-0">
                            <?php if($staffSetting->user->photo): ?>
                                <img src="<?php echo e(asset('upload/staff_images/' . $staffSetting->user->photo)); ?>" 
                                     alt="<?php echo e($staffSetting->user->name); ?>" 
                                     style="width: 100px; height: 100px; border-radius: 100%;">
                            <?php else: ?>
                                <div style="width: 100px; height: 100px; border-radius: 100%; background-color: #ccc; display: flex; align-items: center; justify-content: center; font-size: 12px; color: white;">
                                    No Image
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Buttons Section -->
                    <div class="box-body">
                        <div class="d-flex justify-content-between">
                            
                            <!-- Active Status Buttons -->
                            <div class="media-body">
                                <h5 class="text-muted mb-3">InActive Status</h5>
                                
                                <form action="<?php echo e(route('admin.transaction.inactivateAccount')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="staff_id" value="<?php echo e($staffSetting->user->id); ?>">
                                    <input type="hidden" name="s_accounts" value="inactive">
                                    <button type="submit" class="button button-outline button-warning mb-3">
                                        <span>Accounts</span>
                                    </button>
                                </form>
                                
                                <form action="<?php echo e(route('admin.transaction.inactivateItems')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="staff_id" value="<?php echo e($staffSetting->user->id); ?>">
                                    <input type="hidden" name="s_item" value="inactive">
                                    <button type="submit" class="button button-outline button-info mb-3">
                                        <span>Items</span>
                                    </button>
                                </form>    
                                
                                
                                <form action="<?php echo e(route('admin.transaction.inactivateTransaction')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="staff_id" value="<?php echo e($staffSetting->user->id); ?>">
                                    <input type="hidden" name="s_transaction" value="inactive">
                                    <button type="submit" class="button button-outline button-secondary mb-3">
                                        <span>Transaction</span>
                                    </button>
                                </form>   
                                
                            </div>

                            <div class="media-body">
                                <h5 class="text-muted mb-3">STATUS</h5>
                            
                                
                                <form action="#" method="POST">
                                    <button type="submit" class="button button-outline mb-3" disabled>
                                        <span class="fw-bold"><?php echo e($staffSetting->s_accounts); ?></span>
                                    </button>
                                </form>
                            
                                
                                <form action="#" method="POST">
                                    <button type="submit" class="button button-outline mb-3" disabled>
                                        <span class="fw-bold"><?php echo e($staffSetting->s_item); ?></span>
                                    </button>
                                </form>
                            
                                
                                <form action="#" method="POST">
                                    <button type="submit" class="button button-outline mb-3" disabled>
                                        <span class="fw-bold"><?php echo e($staffSetting->s_transaction); ?></span>
                                    </button>
                                </form>
                            </div>
                            
                            
                            <!-- Inactive Status Buttons -->
                            <div class="media-body">
                                <h5 class="text-muted mb-3">Active Status</h5>
                                
                                <form action="<?php echo e(route('admin.transaction.activateAccount')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="staff_id" value="<?php echo e($staffSetting->user->id); ?>">
                                    <input type="hidden" name="s_accounts" value="active">
                                    <button type="submit" class="button button-outline button-warning mb-3">
                                        <span>Accounts</span>
                                    </button>
                                </form>  

                                
                                <form action="<?php echo e(route('admin.transaction.activateItems')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="staff_id" value="<?php echo e($staffSetting->user->id); ?>">
                                    <input type="hidden" name="s_item" value="active">
                                    <button type="submit" class="button button-outline button-info mb-3">
                                        <span>Items</span>
                                    </button>
                                </form> 

                                 
                                 <form action="<?php echo e(route('admin.transaction.activateTransaction')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="staff_id" value="<?php echo e($staffSetting->user->id); ?>">
                                    <input type="hidden" name="s_transaction" value="active">
                                    <button type="submit" class="button button-outline button-secondary mb-3">
                                        <span>Transaction</span>
                                    </button>
                                </form>  
                            </div>
                        </div>

                    </div> <!-- End of Box Body -->

                </div> <!-- End of Box -->
            </div> <!-- End of Staff Setting Column -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div> <!-- Staff Settings List End -->

</div>
<!-- Content Body End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\limms3.0\resources\views/admin/admin_staff_settings.blade.php ENDPATH**/ ?>