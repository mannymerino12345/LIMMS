

<?php $__env->startSection('admin'); ?>
<div class="content-body">
    <!-- Page Headings Start -->
    <div class="row justify-content-between align-items-center mb-10">
        <div class="col-12 col-lg-auto mb-20">
            <div class="page-heading">
                <h3 class="title">Table <span>/ Transaction Management</span></h3>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-12 mb-30">
            <div class="box">
                <div class="box-head">
                    <h3 class="title">Transaction Table</h3>
                </div>
                <div class="box-body">
                    <!-- Success Message -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <button class="button button-outline button-info" type="button" id="select_all_button" onclick="selectAllCheckboxes()">Select All</button>
                    <form action="<?php echo e(route('admin.transaction.approveMultiple')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <table class="table footable"
                               data-paging="true"
                               data-filtering="true"
                               data-sorting="true"
                               data-breakpoints='{ "xs": 480, "sm": 768, "md": 992, "lg": 1200, "xl": 1400 }'>
                            <thead>
                                <tr>
                                    <th> Select</th>
                                    <th>Transaction ID</th>
                                    <th>User</th>
                                    <th>Item</th>
                                    <th>Quantity</th>
                                    <th>Borrow Date</th>
                                    <th>Due Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><input type="checkbox" name="transactions[]" value="<?php echo e($transaction->transaction_id); ?>" class="adomx-checkbox info"></td> <!-- Checkbox for each transaction -->
                                        <td><?php echo e($transaction->transaction_id); ?></td>
                                        <td><?php echo e($transaction->user->id_number); ?></td>
                                        <td><?php echo e($transaction->item->item_name); ?></td>
                                        <td><?php echo e($transaction->quantity); ?></td>
                                        <td><?php echo e($transaction->borrow_date); ?> <?php echo e($transaction->borrow_time); ?></td>
                                        <td><?php echo e($transaction->due_date); ?> <?php echo e($transaction->due_time); ?></td>
                                        <td><?php echo e($transaction->status); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <button type="submit" class="button button-outline button-success">Approve Selected</button>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function toggleSelectAll() {
        // Get the 'select_all' checkbox
        var selectAllCheckbox = document.getElementById("select_all");

        // Get all checkboxes
        var checkboxes = document.querySelectorAll(".adomx-checkbox");

        // Loop through all checkboxes and set their checked property based on 'select_all'
        checkboxes.forEach(function(checkbox) {
            checkbox.checked = selectAllCheckbox.checked;
        });
    }
</script>
<script>
    function selectAllCheckboxes() {
        // Get all checkboxes with the class "adomx-checkbox"
        var checkboxes = document.querySelectorAll('.adomx-checkbox');
        
        // Check if all checkboxes are already selected
        var allChecked = Array.from(checkboxes).every(function(checkbox) {
            return checkbox.checked;
        });

        // Loop through each checkbox and toggle the checked state
        checkboxes.forEach(function(checkbox) {
            checkbox.checked = !allChecked; // If all are checked, uncheck them; otherwise, check all
        });
    }
</script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\limms3.0\resources\views/admin/admin_transaction_management/admin_transaction_request.blade.php ENDPATH**/ ?>