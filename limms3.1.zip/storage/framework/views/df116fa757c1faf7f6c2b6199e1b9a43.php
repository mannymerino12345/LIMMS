

<?php $__env->startSection('staff'); ?>
<!-- Content Body Start -->
<div class="content-body">

    <!-- Page Headings Start -->
    <div class="row justify-content-between align-items-center mb-10">

        <!-- Page Heading Start -->
        <div class="col-12 col-lg-auto mb-20">
            <div class="page-heading">
                <h3>Change Password <span>/ Setting</span></h3>
            </div>
        </div><!-- Page Heading End -->

    </div><!-- Page Headings End -->

    <div class="row mbn-30">



        <div class="d-flex justify-content-center align-items-center vh-50">
            <div class="col-lg-6 col-12 mb-30">
                <div class="box">
                    <div class="box-head">
                        <h4 class="title">Change Password</h4>
                    </div>
                    <div class="box-body">
                        <form method="POST" action="<?php echo e(route('staff.password.update')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row mbn-20">
                        
                                <!-- Old Password -->
                                <div class="col-12 mb-20">
                                    <div class="row">
                                        <div class="col-sm-3 col-12 mb-10">
                                            <label for="old_password" class="form-label">Old Password</label>
                                        </div>
                                        <div class="col-sm-9 col-12 mb-10">
                                            <input type="password" id="old_password" name="old_password" 
                                                   class="form-control <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                        
                                <!-- New Password -->
                                <div class="col-12 mb-20">
                                    <div class="row">
                                        <div class="col-sm-3 col-12 mb-10">
                                            <label for="new_password" class="form-label">New Password</label>
                                        </div>
                                        <div class="col-sm-9 col-12 mb-10">
                                            <input type="password" id="new_password" name="new_password" 
                                                   class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                        
                                <!-- Confirm Password -->
                                <div class="col-12 mb-20">
                                    <div class="row">
                                        <div class="col-sm-3 col-12 mb-10">
                                            <label for="new_password_confirmation" class="form-label">Confirm Password</label>
                                        </div>
                                        <div class="col-sm-9 col-12 mb-10">
                                            <input type="password" id="new_password_confirmation" name="new_password_confirmation" 
                                                   class="form-control <?php $__errorArgs = ['new_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['new_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                        
                                <!-- Submit and Cancel Buttons -->
                                <div class="col-12 mb-20">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger">Cancel</a>
                                </div>
                        
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
        

    </div>

</div><!-- Content Body End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('staff.staff_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\limms3.0\resources\views/staff/staff_change_password.blade.php ENDPATH**/ ?>