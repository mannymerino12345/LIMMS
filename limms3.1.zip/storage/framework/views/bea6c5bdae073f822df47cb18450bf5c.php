

<?php $__env->startSection('admin'); ?>
<div class="content-body">
    <!-- Page Headings Start -->
    <div class="row justify-content-between align-items-center mb-10">
        <div class="col-12 col-lg-auto mb-20">
            <div class="page-heading">
                <h3 class="title">Table <span>/ Transaction Management</span></h3>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-12 mb-30">
            <div class="box">
                <div class="box-head">
                    <h3 class="title">Transaction Table</h3>
                </div>
                <div class="box-body">
                    <!-- Success Message -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table footable"
                           data-paging="true"
                           data-filtering="true"
                           data-sorting="true"
                           data-breakpoints='{ "xs": 480, "sm": 768, "md": 992, "lg": 1200, "xl": 1400 }'>
                        <thead>
                            <tr>
                                <th>Transaction ID</th>
                                <th>User</th>
                                <th>Item</th>
                                <th>Quantity</th>
                                <th>Borrow Date</th>
                                <th>Due Date</th>
                                <th>Return Date</th> <!-- Added Return Date Column -->
                                <th>Return Time</th> <!-- Added Return Time Column -->
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($transaction->transaction_id); ?></td>
                                    <td><?php echo e($transaction->user->id_number); ?></td> <!-- Assuming 'id_number' is a column in the 'users' table -->
                                    <td><?php echo e($transaction->item->name); ?></td> <!-- Assuming 'name' is a column in the 'items' table -->
                                    <td><?php echo e($transaction->quantity); ?></td>
                                    <td><?php echo e($transaction->borrow_date); ?> <?php echo e($transaction->borrow_time); ?></td>
                                    <td><?php echo e($transaction->due_date); ?></td> <!-- Fixed repeated due_date column -->
                                    <td><?php echo e($transaction->return_date ?? 'N/A'); ?></td> <!-- Return date (if available) -->
                                    <td><?php echo e($transaction->return_time ?? 'N/A'); ?></td> <!-- Return time (if available) -->
                                    <td><?php echo e($transaction->status); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\limms3.0\resources\views/admin/admin_transaction_management/admin_transaction_returned.blade.php ENDPATH**/ ?>