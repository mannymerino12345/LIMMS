

<?php $__env->startSection('user_content'); ?>
<div class="flat-title-page">
    <div class="themesflat-container">
        <div class="row">
            <div class="col-12">
                <h1 class="heading text-center">Approved Items</h1>
                <ul class="breadcrumbs flex justify-center">
                    <li class="icon-keyboard_arrow_right">
                        <a href="index.html">Home</a>
                    </li>
                    <li>
                        <a href="#">Creators</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="tf-section-2 ranking">
    <div class="themesflat-container">
        <div class="row">
            <div class="col-12 mb-30">
                <div class="widget-tabs relative">
                    
                   
                    
                    <div class="widget-content-tab pt-10">
                        <div class="widget-content-inner active">
                            <div class="widget-table-ranking">
                                <div data-wow-delay="0s" class="wow fadeInUp table-ranking-heading">
                                    <div class="column1">
                                        <h3>Item</h3>
                                    </div>
                                    <div class="column2">
                                        <h3>Borrow Date</h3>
                                    </div>
                                    <div class="column">
                                        <h3>Borrow Time</h3>
                                    </div>
                                    <div class="column">
                                        <h3>Due Date</h3>
                                    </div>
                                    <div class="column">
                                        <h3>Quantity</h3>
                                    </div>
                                    <div class="column">
                                        <h3>Status</h3>
                                    </div>
                                    <div class="column">
                                        
                                    </div>
                                </div>
                                <div class="table-ranking-content">
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                    <div data-wow-delay="0s" class="wow fadeInUp fl-row-ranking">
                                        <div class="td1">
                                            <div class="item-rank"><?php echo e($loop->iteration); ?>.</div>
                                            <div class="item-avatar">
                                                <img src="<?php echo e($transaction->item && $transaction->item->item_image && file_exists(public_path($transaction->item->item_image)) 
                                                ? url($transaction->item->item_image) 
                                                : url('assets/images/avatar/avatar-07.png')); ?>" alt="">
                                            </div>
                                            <div class="item-name">
                                                <?php echo e($transaction->item->item_name); ?>

                                            </div>
                                        </div>
                                        <div class="td2">
                                            <h6 class="price gem">
                                                <?php echo e($transaction->borrow_date); ?>

                                            </h6>
                                        </div>
                                        <div class="td3 danger">
                                            <?php echo e($transaction->borrow_time); ?>

                                        </div>
                                        
                                        <div class="td2">
                                            <?php echo e($transaction->due_date); ?>

                                        </div>
                                        <div class="td4 warning">
                                            <?php echo e($transaction->quantity); ?>

                                        </div>
                                        <div class="td7 warning">
                                            <h6 class="price gem">
                                                <?php echo e($transaction->status); ?>

                                            </h6>
                                        </div>
                                        <div class="td7">
                                            
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="widget-pagination">
                    <ul class="justify-center">
                        
                        <?php if($transactions->onFirstPage()): ?>
                            <li class="disabled">
                                <a href="<?php echo e(url()->current()); ?>"><i class="icon-keyboard_arrow_left"></i></a>
                            </li>
                        <?php else: ?>
                            <li>
                                <a href="<?php echo e($transactions->previousPageUrl()); ?>"><i class="icon-keyboard_arrow_left"></i></a>
                            </li>
                        <?php endif; ?>
            
                        
                        <?php $__currentLoopData = $transactions->getUrlRange(1, $transactions->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $transactions->currentPage()): ?>
                                <li class="active">
                                    <a href="#"><?php echo e($page); ?></a>
                                </li>
                            <?php else: ?>
                                <li>
                                    <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                        
                        <?php if($transactions->hasMorePages()): ?>
                            <li>
                                <a href="<?php echo e($transactions->nextPageUrl()); ?>"><i class="icon-keyboard_arrow_right"></i></a>
                            </li>
                        <?php else: ?>
                            <li class="disabled">
                                <a href="<?php echo e(url()->current()); ?>"><i class="icon-keyboard_arrow_right"></i></a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.user_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\limms3.0\resources\views/user/item/item_approved.blade.php ENDPATH**/ ?>