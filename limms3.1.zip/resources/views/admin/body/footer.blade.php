<div class="footer-section">
    <div class="container-fluid">

        <div class="footer-copyright text-center">
            <p class="text-body-light">2022 &copy; <a href="https://themeforest.net/user/codecarnival">SLSU LIMMS</a></p>
        </div>

    </div>
</div>